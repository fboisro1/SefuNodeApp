let payRate = 0.00;
let hours = 0.0;
let r;
let name = "";
let userArray = [];


var UserObj = function (pUserWage, pUserHours, pName) {
    this.UserWage = pUserWage;
    this.UserHours = pUserHours;
    this.Name = pName;
    this.ID = userArray.length + 1;
    
}

userArray.push(new UserObj(25, 84, "Sefu Kaba"));
userArray.push(new UserObj(27, 86, "Roofus"));
userArray.push(new UserObj(28, 85, "Roody"));

    
    document.addEventListener("DOMContentLoaded", function(){

        document.getElementById("buttonSave").addEventListener("click", function () {
            userArray.push(new UserObj(document.getElementById("wages").value, 
            document.getElementById("hours").value, 
            document.getElementById("name").value));
            
        });

        document.getElementById("calculate").addEventListener("click", function(){
            calcValues();
            //document.location.href = "index.html#listPage";
        });

        document.getElementById("addUser").onclick = function(){
            location.href = "#inputPage";
        };
               
        //need this for when I go back to list page
        $(document).on("pagebeforeshow", "#listPage", function (event) {   // have to use jQuery 
        document.getElementById("results").value;
        document.getElementById("username").value;
        createList();
        
        });
          

        $(document).on("pagebeforeshow", "resultsPage", function (event) {   // have to use jQuery 
        let localID =  document.getElementById("IDparmHere").innerHTML;
        document.getElementById("oneName").innerHTML = "Your name is: " + userArray[userArray.length - 1].Name;
        document.getElementById("oneWage").innerHTML = "Your wages are: " + userArray[userArray.length - 1].UserWage;
        document.getElementById("oneHours").innerHTML = "You have worked " + userArray[userArray.length - 1].UserHours;
        });

    });

    //Task for tomorrow get info from results page and create a list of that info on the list page.
          
// var bla = $('#txt_name').val();

function calcValues() {
    var num1 = $('#hours').val(); // gets input
    var num2 = $('#wages').val();
    name = $('#name').val();

    payRate = num1; //sets the global variable payRate to user input 
    hours = num2;
     


    num1 = Number(document.formcalc.hours.value);
    num2 = Number(document.formcalc.wages.value);
    var results = num1 * num2;
    r = results;
    document.getElementById("results").innerHTML = results;
    document.getElementById("username").innerHTML = name;
   

   
}

function createList()
{
  // clear prior data
  var divUserList = document.getElementById("divUserList");
  while (divUserList.firstChild) {    // remove any old data so don't get duplicates
  divUserList.removeChild(divUserList.firstChild);
  };

  var ul = document.createElement('ul');  
  console.log(userArray);
  userArray.forEach(function (element) {   // use handy array forEach method
    var li = document.createElement('li');
    li.innerHTML = "<a data-transition='pop' class='oneList' data-parm=" + element.ID + "  href='#listPage'>Get Details </a> " + element.ID + ":  " + "UserName: "+ element.Name + "    " +"Hours: " + element.UserHours + " " + "Wages: " + element.UserWage;
    ul.appendChild(li);
  });
  divUserList.appendChild(ul)

    //set up an event for each new li item, if user clicks any, it writes >>that<< items data-parm into the hidden html 
    var classname = document.getElementsByClassName("oneList");
    Array.from(classname).forEach(function (element) {
        element.addEventListener('click', function(){
            var parm = this.getAttribute("data-parm");  // passing in the record.Id
            //do something here with parameter on  pickbet page
            document.getElementById("IDparmHere").innerHTML = parm;
            document.location.href = "index.html#resultsPage";
        });
    });
   
};